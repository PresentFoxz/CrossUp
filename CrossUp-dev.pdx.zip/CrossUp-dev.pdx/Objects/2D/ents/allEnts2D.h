#ifndef ALLENTS2D_H
#define ALLENTS2D2_H

#include "cross/crossdata2D.h"

static const int entDataCount2D = 1;

static const entData_t entData2D[] = {
    {cross_animNames2D, cross_animFrameCounts2D, cross_totalAnims2D},
};

#endif