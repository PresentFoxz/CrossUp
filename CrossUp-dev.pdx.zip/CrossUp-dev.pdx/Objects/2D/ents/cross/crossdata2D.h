#ifndef CROSSDATA2D_H
#define CROSSDATA2D_H

static const char* cross_animNames2D[] = {
    "Objects/2D/ents/cross/idle.fox"
};

static const int cross_animFrameCounts2D[1] = { 1 };
static const int cross_totalAnims2D = 1;

#endif