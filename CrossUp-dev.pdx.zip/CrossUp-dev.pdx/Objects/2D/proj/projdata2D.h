#ifndef PROJDATA2D_H
#define PROJDATA2D_H

static const int projDataCount2D = 0;

static const char* projObjs2D[] = {
    "Objects/3D/proj/ball.fox",
};

#endif