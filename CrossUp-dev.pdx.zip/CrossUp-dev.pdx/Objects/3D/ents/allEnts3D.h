#ifndef ALLENTS_H
#define ALLENTS_H

#include "cross/crossdata3D.h"

static const int entDataCount3D = 1;

static const entData_t entData3D[] = {
    {cross_animNames3D, cross_animFrameCounts3D, cross_totalAnims3D},
};

#endif