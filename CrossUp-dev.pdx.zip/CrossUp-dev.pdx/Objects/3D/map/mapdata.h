#ifndef MAPDATA_H
#define MAPDATA_H

static const char* mapObjs[] = {
    "Objects/3D/map/testplate.obj",
};

static const int mapData[][2] = {
    {0, 1},
};

#endif