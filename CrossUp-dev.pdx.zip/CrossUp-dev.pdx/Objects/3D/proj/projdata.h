#ifndef PROJDATA_H
#define PROJDATA_H

static const int projDataCount = 1;

static const char* projObjs[] = {
    "Objects/3D/proj/ball.obj",
};

static const int projData[][2] = {
    {0, 0},
};

#endif