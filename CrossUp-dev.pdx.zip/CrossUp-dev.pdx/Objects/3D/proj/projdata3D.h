#ifndef PROJDATA_H
#define PROJDATA_H

static const int projDataCount3D = 1;

static const char* projObjs3D[] = {
    "Objects/3D/proj/ball.obj",
};

static const int projData3D[][2] = {
    {0, 0},
};

#endif