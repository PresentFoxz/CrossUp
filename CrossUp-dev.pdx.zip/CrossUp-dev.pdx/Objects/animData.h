#ifndef ANIMDATA_H
#define ANIMDATA_H

// 3D objects
#include "3D/ents/allEnts.h"
#include "3D/map/mapdata.h"
#include "3D/proj/projdata.h"

#endif