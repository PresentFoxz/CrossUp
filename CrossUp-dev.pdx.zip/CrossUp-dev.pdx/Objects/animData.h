#ifndef ANIMDATA_H
#define ANIMDATA_H

#include "ents/allEnts.h"
#include "map/mapdata.h"

#endif