#ifndef ALLENTS_H
#define ALLENTS_H

#include "cross/crossdata.h"

static const int entDataCount = 1;

static const entData_t entData[] = {
    {cross_animNames, cross_animFrameCounts, cross_totalAnims},
};

#endif