#ifndef MAPDATA_H
#define MAPDATA_H

static const char* mapObjs[] = {
    "Objects/map/Castle.obj",
    "Objects/map/testplate.obj",
};

static const int mapData[][2] = {
    {0, 0},
    {0, 1},
};

#endif